<?php
/*If button is submitted hence using If-statement*/
     if(isset($_POST['Submit'])){

        $url='https://www.google.com/recaptcha/api/siteverify';
        $privatekey="gUAAAAAFqO4g0888QNSp8YwwkbX7Dd4ag7";
        
        <!--Handling response-->
        $response=file_get_contents($url."?secrete=".privatekey."&response".$_POST['g-recaptcha-response']."&remoteip=".$_SERVER['REMOTE_ADDR']);
        /*Creating variable called data*/
        $data= json_decod($response);

        if(isset($data->sucess) AND $data->sucess==true){
            header('Location: Contact.php?CaptchaPass=True');

        }else{
            header('Location: Contact.php?CaptchaFail=True');
        }
     }

?>

<?php if(isset($_GET['CaptchaPass'])){ ?>
                    <div class="contact">Message Sent</div>   
                    <?php } ?>
                    <?php if(isset($_GET['CaptchaFail'])){ ?>
                    <div class="contact">Captcha Failed. Please try again</div>   
                    <?php } ?>
<!--link for google recaptcha to the server-->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
                     <!--Linking drop html file to Contact php file-->
         <link rel="stylesheet" href="Contact.php">

            <!--Robot-->
            <div class="Robot">
                        <div class="g-recaptcha" data-sitekey="6Ld2LNgUAAAAAACOJdnJFFWNun9c2JxC68DnEKHJ"></div> 
                        </div>