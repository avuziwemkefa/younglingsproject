// Initialize Firebase (ADD YOUR OWN DATA)
var config = {
    apiKey: "AIzaSyBAuxXgGjdVfXM43f2ZqnmLGKgAig1mFrU",
    authDomain: "avu-s-portfolio.firebaseapp.com",
    databaseURL: "https://avu-s-portfolio.firebaseio.com",
    projectId: "avu-s-portfolio",
    storageBucket: "avu-s-portfolio.appspot.com",
    messagingSenderId: "501243827984",
    appId: "1:501243827984:web:501a7cccd8baf0461c7795",
    measurementId: "G-71HQLBPX0J"
  };
  firebase.initializeApp(config);
  
  // Reference messages collection
  var messagesRef = firebase.database().ref('messages');
  
  // Listen for form submit
  document.getElementById('contactForm').addEventListener('submit', submitForm);
  
  // Submit form
  function submitForm(e){
    e.preventDefault();
  
    // Get values
    var name = getInputVal('name');
    var subject = getInputVal('subject');
    var email = getInputVal('email');
    var phone = getInputVal('phone');
    var message = getInputVal('message');
  
    // Save message
    saveMessage(name, subject, email, phone, message);
  
  // Function to get get form values
  function getInputVal(id){
    return document.getElementById(id).value;
  }
  
  // Save message to firebase
  function saveMessage(name, subject, email, phone, message){
    var newMessageRef = messagesRef.push();
    newMessageRef.set({
      name: name,
      subject:subject,
      email:email,
      phone:phone,
      message:message
    });
    }
}